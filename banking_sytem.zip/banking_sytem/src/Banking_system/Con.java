package Banking_system;

import java.sql.*;

public class Con {

    Connection connection;
    public Statement statement;

    public Con() {
        try {
            // Optionally load the driver if needed
            Class.forName("com.mysql.cj.jdbc.Driver");

            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankSystem", "root", "Sagarneil123@");
            statement = connection.createStatement();
        } catch(SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
    public void close() {
        try {
            if (statement != null) statement.close();
            if (connection != null) connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}